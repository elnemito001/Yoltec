export const environment = {
  production: false,
  apiUrl: 'http://localhost:8000/api',
  appName: 'Yoltec - Consultorio Médico'
};
